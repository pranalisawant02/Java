DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS mobile;
DROP TABLE IF EXISTS orders;

CREATE TABLE user(
    userid INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(20),
    email VARCHAR(50),
    password VARCHAR(50),
    city VARCHAR(20)
);

CREATE TABLE mobile(
    mobileid INT PRIMARY KEY AUTO_INCREMENT,
    company VARCHAR(20),
    model VARCHAR(30),
    price DECIMAL(9,2)
);

CREATE TABLE orders(
    orderid INT PRIMARY KEY AUTO_INCREMENT,
    mobileid INT ,
    userid INT
);


INSERT INTO user(name,email,password,city) VALUES("Anil","anil@gmail.com","anil","Mumbai");
INSERT INTO user(name,email,password,city) VALUES("Mukesh","mukesh@gmail.com","mukesh","Mumbai");

INSERT INTO mobile(company,model,price) VALUES("Samsung","S23",40000);
INSERT INTO mobile(company,model,price) VALUES("Samsung","Z fold",100000);
INSERT INTO mobile(company,model,price) VALUES("Vivo","Y35",250000);
